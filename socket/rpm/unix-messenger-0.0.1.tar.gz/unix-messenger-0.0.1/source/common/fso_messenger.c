#include "fso_messenger_module.h"

int main(void){
  init_messenger_module(); 
  return 0;
}
