#! /bin/bash

PACKAGE_NAME="unix-messenger"

# Install Development Tools
sudo yum groupinstall "Development Tools" 

# Generate RPM package tree
rpmdev-setuptree

# Move Tarball to the RPM SOURCE dir
mv *.tar.gz /home/$USER/rpmbuild/SOURCES
mv *.spec   /home/$USER/rpmbuild/SPECS

# Generate rpm package
rpmbuild -ba $PACKAGE_NAME.spec
